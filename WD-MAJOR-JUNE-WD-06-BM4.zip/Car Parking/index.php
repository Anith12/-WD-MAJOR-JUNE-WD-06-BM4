<?php
    $conn = mysqli_connect("localhost", "root", "", "parking");
    $count = 0;
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="theme-color" content="#29C3CB">
        <title>Parking Management</title>
        <link rel="stylesheet" href="css/fa/css/fontawesome.min.css">
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body>
        <header>
            <div class="content">
                <h1><i class="fa-regular fa-parking"></i>Parking Lot Management</h1>
            </div>
        </header>
        <section>
            <div class="container">
                <div class="content">
                    <h2><i class="fa-regular fa-car"></i>Add vehicle to parking lot</h2>
                    <form name="" action="" method="POST" enctype="multipart/form-data" autocomplete="on">
                        <div class="input-group">
                            <div class="input-box">
                                <input type="text" name="owner_name" id="txtOwnerName" placeholder="Owner name">
                                <i class="fa-regular fa-user prepend"></i>
                            </div>
                            <div class="input-box">
                                <input type="tel" name="owner_mobile" id="txtOwnerMobile" placeholder="Mobile no">
                                <i class="fa-regular fa-phone prepend"></i>
                            </div>
                        </div>
                        <div class="input-group">
                            <div class="input-box">
                                <input type="text" name="vehicle_brand" id="txtBrand" placeholder="Brand">
                                <i class="fa-regular fa-car prepend"></i>
                            </div>
                            <div class="input-box">
                                <input type="text" name="vehicle_model" id="txtModel" placeholder="Model">
                                <i class="fa-regular fa-car-alt prepend"></i>
                            </div>
                            <div class="input-box">
                                <input type="text" name="vehicle_reg_no" id="txtRegNo" placeholder="Registered no">
                                <i class="fa-regular fa-credit-card-front prepend"></i>
                            </div>
                        </div>
                        <div class="input-group">
                            <div class="input-box">
                                <input type="datetime-local" name="entry_date_time" id="txtEntryDT">
                                <i class="fa-regular fa-arrow-right-to-bracket prepend"></i>
                            </div>
                            <div class="input-box">
                                <input type="datetime-local" name="exit_date_time" id="txtExitDT">
                                <i class="fa-regular fa-arrow-right-from-bracket prepend"></i>
                            </div>
                        </div>
                        
                        <div class="input-group">
                            <div class="input-box">
                                <button class="btn btn-bg" name="btn_add_vehicle" id="btnAddVehicle"><i class="fa-regular fa-car-garage"></i>Add Vehicle</button>
                            </div>
                        </div>
                    </form>

                    <?php

                        if (isset($_POST["btn_add_vehicle"])) {

                            $owner_name = $_POST['owner_name'];
                            $owner_mobile = $_POST['owner_mobile'];
                            $vehicle_brand = $_POST['vehicle_brand'];
                            $vehicle_model = $_POST['vehicle_model'];
                            $vehicle_reg_no = $_POST['vehicle_reg_no'];
                            $entry_date_time = $_POST['entry_date_time'];
                            $exit_date_time = $_POST['exit_date_time'];

                            $sql = "INSERT INTO vehicle_list (`owner_name`, `owner_mobile`, `vehicle_brand`, `vehicle_model`, `vehicle_reg_no`, `entry_date_time`, `exit_date_time`) VALUES ('$owner_name', '$owner_mobile', '$vehicle_brand', '$vehicle_model', '$vehicle_reg_no', '$entry_date_time', '$exit_date_time')";

                            $insert = mysqli_query($conn, $sql);

                            if (!$insert) {

                                echo '<script>
                                    alert("Connection error!");
                                </script>'; 
                            }
                            else{
                                // echo '<script>
                                //     alert("Vehicle added to parking lot.");
                                // </script>'; 
                            }
                        }
                    
                    ?>

                </div>
            </div>
        </section>
        <section>
            <div class="container" style="padding-top: 0;">
                <div class="content">
                    <h2><i class="fa-regular fa-list-alt"></i>List of vehicles in the parking lot</h2>
                    <form name="" action="#" method="POST" enctype="multipart/form-data" autocomplete="on">
                        <div class="input-group">
                            <div class="input-box">
                                <input type="text" name="" id="txtSearch" placeholder="Search Anything....." required>
                                <i class="fa-regular fa-search prepend"></i>
                            </div>
                        </div>
                    </form>
                    <div class="table-container">
                        <table id="vehicleList">
                            <thead>
                                <tr>
                                    <th><i class="fa-regular fa-user"></i>Owner Name</th>
                                    <th><i class="fa-regular fa-phone"></i>Mobile No</th>
                                    <th><i class="fa-regular fa-car"></i>Brand</th>
                                    <th><i class="fa-regular fa-car-alt"></i>Model</th>
                                    <th><i class="fa-regular fa-credit-card-front"></i>Registered No</th>
                                    <th><i class="fa-regular fa-arrow-right-to-bracket"></i>Entry Date-Time</th>
                                    <th><i class="fa-regular fa-arrow-right-from-bracket"></i>Exit Date-Time</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php
                                
                                    $sql = "SELECT * FROM vehicle_list";
                                    $result = mysqli_query($conn, $sql);

                                    while ($row = mysqli_fetch_assoc($result)) {
                                        $count++;
                                        echo '
                                            
                                            <tr>
                                                <td>'.$row['owner_name'].'</td>
                                                <td>'.$row['owner_mobile'].'</td>
                                                <td>'.$row['vehicle_brand'].'</td>
                                                <td>'.$row['vehicle_model'].'</td>
                                                <td>'.$row['vehicle_reg_no'].'</td>
                                                <td>'.$row['entry_date_time'].'</td>
                                                <td>'.$row['exit_date_time'].'</td>
                                                <td>
                                                    <button class="edit"><i class="fa-regular fa-pen"></i></button>
                                                    <button class="delete"><i class="fa-regular fa-trash"></i></button>
                                                </td>
                                            </tr>
                                            
                                        ';
                                        
                                    }

                                ?>

                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="8" style="text-align: left;">Total vehicle(s) = <?php echo $count; ?></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </section>

        <script src="js/jquery.min.js"></script>
        <script src="js/script.js"></script>
    </body>
</html>